import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.nio.file.Files;
import java.nio.file.Paths;

public class SeedRunner {
    public static void main(String[] args) {
        String dbUrl = "jdbc:mysql://localhost:3306/smartskillmap?allowMultiQueries=true";
        String user = "root";
        String pass = "root25";
        String sqlFilePath = "database/reset_and_seed_final.sql";

        try {
            System.out.println("Reading SQL file...");
            String sqlContent = new String(Files.readAllBytes(Paths.get(sqlFilePath)));

            System.out.println("Connecting to Database...");
            // Load driver in case it's needed explicitly
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection conn = DriverManager.getConnection(dbUrl, user, pass);
                 Statement stmt = conn.createStatement()) {
                
                System.out.println("Executing SQL statements...");
                stmt.execute(sqlContent);
                System.out.println("SUCCESS! Database has been completely seeded.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

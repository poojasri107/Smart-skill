/**
 * TEST.JS - VERSION 5.0 (FINAL RECOVERY)
 */
const SCRIPT_VERSION = "5.0";
console.log("SMART-SKILL-MAP SCRIPT LOADED: V", SCRIPT_VERSION);

let currentQuestions = [];

/**
 * Universal function to start a test
 * ALWAYS uses URL parameters for 100% reliability
 */
function startTest(courseName) {
    console.log("Navigating to test for:", courseName);
    // Explicitly navigate with unique version to bypass all browser caches
    window.location.href = "test.html?course=" + encodeURIComponent(courseName) + "&v=" + new Date().getTime();
}

/**
 * Initialization Logic - Runs only on test.html
 */
document.addEventListener("DOMContentLoaded", function () {
    const container = document.getElementById("questionsContainer");
    if (!container) return;

    // Visual Version Indicator for the User
    console.log("Initializing Test Page Logic V" + SCRIPT_VERSION);

    // 1. Get Course from URL
    const params = new URLSearchParams(window.location.search);
    const course = params.get("course");

    if (!course) {
        container.innerHTML = "<div style='padding:50px; text-align:center;'><h3>No course selected.</h3><p>Please go back to Dashboard and pick a course.</p><button onclick='window.history.back()'>Go Back</button></div>";
        return;
    }

    // Update Title
    const titleElement = document.getElementById("courseTitle");
    if (titleElement) {
        titleElement.innerHTML = `Assessment: <span style="color:#007bff; border-bottom:2px solid #007bff">${course}</span>`;
    }

    // Initial Loading State
    container.innerHTML = `<div style="text-align:center; padding:50px;">
        <div style="border: 4px solid #f3f3f3; border-top: 4px solid #3498db; border-radius: 50%; width: 30px; height: 30px; animation: spin 2s linear infinite; margin: 0 auto;"></div>
        <p style="margin-top:20px">Preparing unique questions for ${course}...</p>
    </div>`;

    // 2. Fetch the FINAL JSON (timestamped for anti-cache)
    fetch('js/questions_final.json?t=' + new Date().getTime())
        .then(response => {
            if (!response.ok) throw new Error("Could not load question database.");
            return response.json();
        })
        .then(data => {
            console.log("Database keys available:", Object.keys(data));

            // 3. ADVANCED Mapping
            let category = "Computer Science Engineering";

            // Try Case-Sensitive Match first
            if (data[course]) {
                category = course;
            } else {
                // Try fuzzy lower-case match
                const lowerCourse = course.toLowerCase();
                const keys = Object.keys(data);
                const foundKey = keys.find(k => k.toLowerCase() === lowerCourse);

                if (foundKey) {
                    category = foundKey;
                } else {
                    // Fallback categories if neither works
                    if (lowerCourse.includes("it")) category = "Information Technology";
                    else if (lowerCourse.includes("mbbs")) category = "MBBS";
                    else if (lowerCourse.includes("doctor")) category = "MBBS";
                    else if (lowerCourse.includes("dental") || lowerCourse.includes("bds")) category = "BDS";
                    else if (lowerCourse.includes("law") || lowerCourse.includes("llb")) category = "LLB";
                    else if (lowerCourse.includes("diploma")) {
                        if (lowerCourse.includes("mech")) category = "Diploma in Mechanical Engineering";
                        else if (lowerCourse.includes("computer")) category = "Diploma in Computer Science";
                        else category = "Diploma in Civil Engineering";
                    }
                }
            }

            console.log("SUCCESS: Loading unique set for category:", category);
            currentQuestions = data[category] || data["Computer Science Engineering"];

            // 4. Update UI with explicit verification box
            container.innerHTML = `
                <div style="background:#fffcf0; padding:15px; border-radius:10px; margin-bottom:25px; border:1px solid #ffecb5; display:flex; justify-content:space-between; align-items:center;">
                    <div style="font-weight:700; color:#856404;">
                        <span style="background:#ffeeb5; padding:4px 8px; border-radius:5px; margin-right:10px;">ID: ${category}</span>
                        <span>Questions: ${currentQuestions.length}</span>
                    </div>
                    <div style="font-size:12px; color:#aaa;">System: V3.Final</div>
                </div>
            `;

            // 5. Render Questions
            currentQuestions.forEach((q, index) => {
                const qDiv = document.createElement("div");
                qDiv.className = "question-card";
                qDiv.setAttribute("style", "background:white; border-radius:15px; padding:25px; box-shadow:0 8px 30px rgba(0,0,0,0.05); margin-bottom:30px; border:1px solid #f0f4f8; position:relative;");

                let optionsHtml = q.options.map((opt, optIndex) => `
                    <div style="margin: 12px 0; background:#f9fbff; padding:15px; border-radius:10px; transition: all 0.2s; border:1px solid #eef2f7; cursor:pointer;" 
                         onclick="document.getElementById('q${index}_${optIndex}').checked = true">
                        <input type="radio" name="q${index}" value="${optIndex}" id="q${index}_${optIndex}" style="margin-right:12px; transform:scale(1.3);">
                        <label for="q${index}_${optIndex}" style="cursor:pointer; font-size:17px; width:90%; color:#2d3748;">${opt}</label>
                    </div>
                `).join("");

                qDiv.innerHTML = `
                    <div style="position:absolute; top:-12px; left:20px; background:#007bff; color:white; padding:2px 12px; border-radius:20px; font-size:12px; font-weight:700;">Question ${index + 1}</div>
                    <p style="margin-top:10px; font-size:20px; font-weight:600; color:#1a202c; line-height:1.5;">${q.q}</p>
                    <div style="margin-top:20px">${optionsHtml}</div>
                `;
                container.appendChild(qDiv);
            });

            // Sync current Questions to window for submitTest
            window.currentQuestions = currentQuestions;
        })
        .catch(err => {
            console.error("CRITICAL ERROR:", err);
            container.innerHTML = `<div style="padding:40px; text-align:center; background:#fff5f5; border:1px solid #feb2b2; border-radius:10px; color:#c53030;">
                <h3 style="margin-bottom:10px;">Critical Loading Error</h3>
                <p>${err.message}</p>
                <button onclick="location.reload()" style="background:#c53030; color:white; border:none; padding:10px 20px; border-radius:5px; cursor:pointer; margin-top:20px;">Retry Now</button>
            </div>`;
        });
});

/**
 * Submit Test Logic
 */
function submitTest() {
    const qs = window.currentQuestions || currentQuestions;
    if (!qs || qs.length === 0) {
        alert("Assessment is not ready.");
        return;
    }

    let score = 0;
    let answered = 0;
    qs.forEach((q, index) => {
        const selected = document.querySelector(`input[name="q${index}"]:checked`);
        if (selected) {
            answered++;
            if (parseInt(selected.value) === q.answer) {
                score++;
            }
        }
    });

    if (answered < qs.length) {
        if (!confirm(`You only answered ${answered} of ${qs.length} questions. Submit anyway?`)) return;
    }

    // Save
    const params = new URLSearchParams(window.location.search);
    const course = params.get("course") || "General";
    const user = localStorage.getItem("user") || "Guest";

    // DB Call
    fetch('saveResult', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `user=${encodeURIComponent(user)}&course=${encodeURIComponent(course)}&score=${score}`
    }).finally(() => {
        localStorage.setItem("score", score);
        alert(`Assessment Complete!\nCourse: ${course}\nScore: ${score} / ${qs.length}`);
        window.location.href = "result.html";
    });
}
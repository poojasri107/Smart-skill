/**
 * TEST_ULTIMATE.JS - VERSION 9.9 (FINAL HARD RESET)
 */

console.log("!!! ULTIMATE QUIZ SYSTEM V9.9 ENGAGED !!!");

function startTest(courseName) {
    console.log("Redirecting to ultimate test for:", courseName);
    // FORCE hard refresh by changing destination with massive randomizer
    window.location.href = "test.html?course=" + encodeURIComponent(courseName) + "&v=ULTIMATE_" + Math.random().toString(36).substring(7);
}

document.addEventListener("DOMContentLoaded", function () {
    const container = document.getElementById("questionsContainer");
    if (!container) return;

    const params = new URLSearchParams(window.location.search);
    const course = params.get("course");

    if (!course) {
        container.innerHTML = "<h2>Error: No Course Detected</h2>";
        return;
    }

    // Background handled by CSS theme now

    // Update Title
    document.getElementById("courseTitle").innerText = course;

    // Fetch the ULTIMATE JSON
    fetch('js/questions_ultimate.json?cache_kill=' + Date.now())
        .then(res => res.json())
        .then(data => {
            console.log("Ultimate Data Loaded. Keys:", Object.keys(data));

            // PRECISE MAPPING
            let category = course;
            if (!data[course]) {
                // Fuzzy fallback
                const found = Object.keys(data).find(k => k.toLowerCase().includes(course.toLowerCase()));
                category = found || "Computer Science Engineering";
            }

            const questions = data[category];
            window.currentQuestions = questions;

            container.innerHTML = "";

            questions.forEach((q, i) => {
                const qDiv = document.createElement("div");
                qDiv.className = "question-card";

                let options = q.options.map((opt, oi) => `
                    <p><input type="radio" name="q${i}" value="${oi}" id="q${i}_${oi}"> <label for="q${i}_${oi}">${opt}</label></p>
                `).join("");

                // Clean the question text (remove brackets and ID prefix)
                const cleanedQuestion = q.q.replace(/^\[.*?\]\s*\d*:\s*/, "");
                qDiv.innerHTML = `<h4>Question ${i + 1}: ${cleanedQuestion}</h4><div>${options}</div>`;
                container.appendChild(qDiv);
            });
        });
});

function submitTest() {
    const qs = window.currentQuestions;
    if (!qs) return;
    let score = 0;
    qs.forEach((q, i) => {
        const sel = document.querySelector(`input[name="q${i}"]:checked`);
        if (sel && parseInt(sel.value) === q.answer) score++;
    });

    const course = new URLSearchParams(window.location.search).get("course");
    const user = JSON.parse(localStorage.getItem("user"));

    if (!user) {
        alert("Session expired. Please login again.");
        window.location.href = "login.html";
        return;
    }

    const finalScore = Math.round((score / qs.length) * 100);

    // DB Call - Using the new API
    fetch('/api/assessments/submit', {
        method: 'POST',
        headers: { 
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${user.token}`
        },
        body: JSON.stringify({ 
            userId: user.id, 
            assessmentId: 1, // Fallback ID, ideally should be dynamic
            score: finalScore 
        })
    }).finally(() => {
        localStorage.setItem("score", finalScore);
        localStorage.setItem("course", course);
        alert(`Assessment Complete! Score: ${finalScore}%`);
        window.location.href = "dashboard.html"; // Simplified redirect
    });
}

